
<footer class="profile-footer">
&copy Copyright <?php echo date('Y',time()); ?> <font color='tomato' style='font-weight:bold'>StarsApp</font>, All Rights Reserved.
</footer>
</body>

</html>
