
<footer id='loginFooter'>
    &copy Copyright <?php echo date('Y',time()); ?> <font color='tomato' style='font-weight:bold'>StarsApp</font>, All Rights Reserved. <br>
    <i style='font-size:small'>StarsApp is a trademark of  <a style='color:tomato' href='http://appddictionstudio.com' target='_blank'>Appddiction Studio LLC</a></i>
</footer>
</body>
</html>